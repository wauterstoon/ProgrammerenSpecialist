﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFLEAGUEAPP.Migrations
{
    public partial class toonwauters : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "clubs",
                columns: table => new
                {
                    Stamnr = table.Column<string>(nullable: false),
                    Naam = table.Column<string>(nullable: true),
                    Bijnaam = table.Column<string>(nullable: true),
                    Trainer = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clubs", x => x.Stamnr);
                });

            migrationBuilder.CreateTable(
                name: "spelers",
                columns: table => new
                {
                    SpelerId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naam = table.Column<string>(nullable: true),
                    Nummer = table.Column<int>(nullable: false),
                    Club = table.Column<string>(nullable: true),
                    Waarde = table.Column<string>(nullable: true),
                    ClubStamnr = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_spelers", x => x.SpelerId);
                    table.ForeignKey(
                        name: "FK_spelers_clubs_ClubStamnr",
                        column: x => x.ClubStamnr,
                        principalTable: "clubs",
                        principalColumn: "Stamnr",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "transfers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SpelerId1 = table.Column<int>(nullable: true),
                    Transferprijs = table.Column<string>(nullable: true),
                    OudeClub = table.Column<string>(nullable: true),
                    NieuweClub = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_transfers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_transfers_spelers_SpelerId1",
                        column: x => x.SpelerId1,
                        principalTable: "spelers",
                        principalColumn: "SpelerId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_spelers_ClubStamnr",
                table: "spelers",
                column: "ClubStamnr");

            migrationBuilder.CreateIndex(
                name: "IX_transfers_SpelerId1",
                table: "transfers",
                column: "SpelerId1");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "transfers");

            migrationBuilder.DropTable(
                name: "spelers");

            migrationBuilder.DropTable(
                name: "clubs");
        }
    }
}
