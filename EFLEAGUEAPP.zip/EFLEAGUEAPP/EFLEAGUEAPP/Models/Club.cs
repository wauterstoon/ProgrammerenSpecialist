﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EFLEAGUEAPP.Models
{
    class Club
    {
        public Club(List<Speler> spelers)
        {
            Spelers = spelers;
        }

        public Club(string stamnr, string naam, string bijnaam, string trainer)
        {
            Stamnr = stamnr;
            Naam = naam;
            Bijnaam = bijnaam;
            Trainer = trainer;
        }
        [Key]
        public string Stamnr { get; set; }
        public string Naam { get; set; }
        public string Bijnaam { get; set; }
        public string Trainer { get; set; }
        public List<Speler> Spelers { get; set; } = new List<Speler>();


    }
}
