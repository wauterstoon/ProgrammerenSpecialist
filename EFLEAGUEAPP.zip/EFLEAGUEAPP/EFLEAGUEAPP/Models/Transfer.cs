﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFLEAGUEAPP.Models
{
    class Transfer
    {
      

        public Transfer(string transferprijs, string oudeClub, string nieuweClub)
        {
            Transferprijs = transferprijs;
            OudeClub = oudeClub;
            NieuweClub = nieuweClub;
        }

        public int Id { get; set; }
        public string Transferprijs { get; set; }
        public string OudeClub { get; set; }
        public string NieuweClub { get; set; }

    }
}
