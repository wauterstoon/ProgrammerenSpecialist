﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFLEAGUEAPP.Models
{
    class Speler
    {
        public Speler(string naam, int nummer, string club, string waarde)
        {
            Naam = naam;
            Nummer = nummer;
            Club = club;
            Waarde = waarde;
        }

        public int Id { get; set; }
        public string Naam { get; set; }
        public int Nummer { get; set; }
        public string Club { get; set; }
        public string Waarde { get; set; }

    }


}

