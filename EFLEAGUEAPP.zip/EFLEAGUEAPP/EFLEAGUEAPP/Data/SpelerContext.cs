﻿using EFLEAGUEAPP.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFLEAGUEAPP.Data
{
    class SpelerContext : DbContext
    {
        DbSet<Speler> spelers { get; set; }
        DbSet<Club> clubs { get; set; }
        DbSet<Transfer> transfers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            optionsBuilder.UseSqlServer(@"Data Source=DESKTOP-3D66F80\sqlexpress;Initial Catalog=EFLeagueDBToon;Integrated Security=True");
        }


        
    }
}

