﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Monkeys
{
    public class DataBeheer
    {
        public string ConString = "Data Source=laptop-kjn76hfd\\sqlexpress;Initial Catalog=Monkeys;Integrated Security=True";
        public SqlConnection getConn()
        {
            SqlConnection conn = new SqlConnection(ConString);
            return conn;
        }

        public void SchrijfWoodRecordTabel(int mapId, string tekst)
        {
            string[] tussenData = tekst.Split(" ");
            int Id = mapId;
            int treeId = int.Parse(tussenData[4]);
            string xy = tussenData[^1];
            string subXY = xy.Substring(1, xy.Length - 2);
            string[] splitxy = subXY.Split(',');
            int x = int.Parse(splitxy[0]);
            int y = int.Parse(splitxy[1]);

            VoegWoodRecordToe(Id, treeId, x, y);

        }
        public void SchrijfMonkeyRecordsTabel(string tekst)
        {
            string[] tussendata = tekst.Split(',');
            int aapId = int.Parse(tussendata[0]);
            string aapNaam = tussendata[1];
            int mapId = int.Parse(tussendata[2]);
            int seqnr = int.Parse(tussendata[3]);
            int boomId = int.Parse(tussendata[4]);
            float x = float.Parse(tussendata[5]);
            float y = float.Parse(tussendata[6]);

            
            VoegMonkeyRecordToe(aapId, aapNaam, mapId, seqnr, boomId, x, y);
        }
        public void SchrijfLogTabel(string tekst)
        {
            string[] tussendata = tekst.Split(';');
            int mapId = int.Parse(tussendata[0]);
            int aapId = int.Parse(tussendata[1]);
            string message = tussendata[2];

            VoegLogRecordToe(mapId, aapId, message);


        }

        private void VoegLogRecordToe(int mapId, int aapId, string message)
        {
            string query =@"INSERT INTO Logs(woodId,monkeyId,message)
                            VALUES(@woodID,@monkeyID,@message)";
            SqlConnection connection = getConn();
            using(SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                try
                {
                    command.Parameters.Add(new SqlParameter("@woodID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@monkeyID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@message", SqlDbType.NVarChar));
                    command.CommandText = query;

                    command.Parameters["@woodID"].Value = mapId;
                    command.Parameters["@monkeyID"].Value = aapId;
                    command.Parameters["@message"].Value = message;
                    command.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void VoegMonkeyRecordToe(int aapId, string aapNaam, int mapId, int seqnr, int boomId, float x, float y)
        {
            string query = @"INSERT INTO MonkeyRecords(monkeyID,monkeyName,woodID, seqnr,treeID,x,y)
                            VALUES(@monkeyID,@monkeyName,@woodID,@seqnr,@treeID,@x,@y)";
            SqlConnection connection = getConn();
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                try
                {
                    command.Parameters.Add(new SqlParameter("@monkeyID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@monkeyName", SqlDbType.NVarChar));
                    command.Parameters.Add(new SqlParameter("@woodID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@seqnr", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@treeID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@x", SqlDbType.Float));
                    command.Parameters.Add(new SqlParameter("@y", SqlDbType.Float));
                    command.CommandText = query;

                    command.Parameters["@monkeyID"].Value = aapId;
                    command.Parameters["@monkeyName"].Value = aapNaam;
                    command.Parameters["@woodID"].Value = mapId;
                    command.Parameters["@seqnr"].Value = seqnr;
                    command.Parameters["@treeID"].Value = boomId;
                    command.Parameters["@x"].Value = x;
                    command.Parameters["@y"].Value = y;

                    command.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public void SchrijfNaarTxt(Map map)
        {

            using (StreamWriter writer = File.CreateText("ApenRoutes"))
            {

                foreach (Aap aap in map.Apen)
                {
                    foreach (Boom boom in aap.Bomen)
                    {
                        writer.WriteLine(aap.Naam + " is in tree " + boom.Id + " at " + "(" + boom.X + "," + boom.Y + ")");
                    }
                }
            }
        }

        private void VoegWoodRecordToe(int woodId, int treeId, int x, int y)
        {
            string query = @"INSERT INTO WoodRecords(woodID,treeID,x,y)
                            VALUES(@woodID,@treeID,@X,@Y)";
            SqlConnection connection = getConn();
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                try
                {
                    command.Parameters.Add(new SqlParameter("@woodID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@treeID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@X", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@Y", SqlDbType.Int));
                    command.CommandText = query;

                    command.Parameters["@woodID"].Value = woodId;
                    command.Parameters["@treeID"].Value = treeId;
                    command.Parameters["@X"].Value = x;
                    command.Parameters["@Y"].Value = y;

                    command.ExecuteNonQuery();
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
                finally
                {
                    connection.Close();
                }

            }
        }
    }
}
