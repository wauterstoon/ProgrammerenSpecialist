﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading.Tasks;

namespace Monkeys
{
    class Program
    {
        private static List<Task> taks = new List<Task>();
        static async Task Main(string[] args)
        {
            await RunGames(1);

        }
        static Task RunGames(int mapId)
        {
            string path = "E:/Graduaat Programmeren/Semester 2/Programmeren4/Monkeys/Monkeys/bin/Debug/netcoreapp3.1";
            Map map = new Map(1, 0, 500, 0, 500);

            Bitmap bitmap = new Bitmap((map.MaxX - map.MinX), (map.MaxY - map.MinY));
            Random r = new Random();
            int aantal = r.Next(1, 5);
            map.MaakBos(bitmap);
            map.MaakApen(aantal, bitmap);

            foreach (Aap aap in map.Apen)
            {
                taks.Add(Spel(bitmap, map, aap));
            }

            Task.WaitAll(taks.ToArray());

            bitmap.Save(Path.Combine(path, $"{mapId}Escape.jpg"), ImageFormat.Jpeg);

            return Task.CompletedTask;

        }
        static async Task Spel(Bitmap bitmap, Map map, Aap aap)
        {
            //await Task.Delay(500); //Als jullie dit activeren dan loopt het asynchroon maar loopt hij ook dikwijls vast.
            for (int i = 0; i < 200; i++)
            {
                await map.DichtsteBoom(bitmap, aap,i+1);
            }
        }
    }
}
